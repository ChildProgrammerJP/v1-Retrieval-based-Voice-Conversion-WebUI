from .config import singleton_variable, Config, CPUConfig
