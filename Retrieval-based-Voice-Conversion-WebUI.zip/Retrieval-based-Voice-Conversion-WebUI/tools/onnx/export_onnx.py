from infer.modules.onnx.export import export_onnx

export_onnx("pt/Justin Bieber.pth", "pt/TestRvc_Rvc.onnx")
